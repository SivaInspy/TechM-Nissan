#!/bin/sh

ENV="prd"
NAMENODE="bdeprd"
CONNECTIONSTRING="jdbc:hive2://usnencpl075.nmcorp.nissan.biz:2181,usnencpl076.nmcorp.nissan.biz:2181,usnencpl081.nmcorp.nissan.biz:2181/"
OOZIEHOST=usnencpl075.nmcorp.nissan.biz
SOLRHOSTS=usnencpl087.nmcorp.nissan.biz,usnencpl082.nmcorp.nissan.biz,usnencpl083.nmcorp.nissan.biz,usnencpl084.nmcorp.nissan.biz,usnencpl085.nmcorp.nissan.biz,usnencpl086.nmcorp.nissan.biz
RESOURCEMANAGER=usnencpl076.nmcorp.nissan.biz
